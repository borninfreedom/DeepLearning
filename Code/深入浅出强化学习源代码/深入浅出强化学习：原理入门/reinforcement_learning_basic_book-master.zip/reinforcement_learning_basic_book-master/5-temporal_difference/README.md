## 使用方法
1. 参考1-gym_developing里面的[使用方法](https://github.com/zhuliquan/reinforcement_learning_basic_book/blob/master/1-gym_developing/README.md)安装push_box_game环境
环境文件是push_box_game.py

