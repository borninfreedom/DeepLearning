/*
noMeiryoUI (C) 2005,2012-2018 Tatsuhiko Shoji
The sources for noMeiryoUI are distributed under the MIT open source license
*/
//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ �Ő������ꂽ�C���N���[�h �t�@�C���B
// noMeiryoUI.rc �Ŏg�p
//
#define IDC_MYICON                      2
#define ID_SEL_ALL                      3
#define ID_SEL_TITLE                    4
#define ID_SEL_ICON                     5
#define ID_SEL_PALETTE                  6
#define ID_SEL_HINT                     7
#define ID_SEL_MESSAGE                  8
#define ID_SEL_MENU                     9
#define ID_SET_ALL                      11
#define IDD_NOMEIRYOUI_DIALOG           102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDD_MAIN_DIALOG                 103
#define IDM_ABOUT                       104
#define IDS_VERSION                     104
#define IDI_NOMEIRYOUI                  107
#define IDI_SMALL                       108
#define IDC_NOMEIRYOUI                  109
#define IDR_MAINFRAME                   128
#define IDR_RT_MANIFEST1                129
#define IDR_RT_MANIFEST                 131
#define IDD_DIALOG_FONTSEL              132
#define IDR_MENU1                       133
#define IDC_EDIT_ALL                    1000
#define IDC_EDIT_TITLE                  1001
#define IDC_COMBO_NAME                  1001
#define IDC_EDIT_ICON                   1002
#define IDC_EDIT_PALETTE                1003
#define IDC_COMBO_STYLE                 1003
#define IDC_EDIT_HINT                   1004
#define IDC_COMBO_SIZE                  1004
#define IDC_EDIT_MESSAGE                1005
#define IDC_COMBO_CHARSET               1005
#define IDC_EDIT_MENU                   1006
#define IDC_CHECK_UNDERLINE             1006
#define IDC_CHECK_STRIKE                1008
#define IDC_STATIC_VERNO                1009
#define IDC_STATIC_APP_TITLE            1010
#define IDC_STATIC_WIN_VER              1011
#define IDC_STATIC_ALL_FONT             1012
#define IDC_STATIC_TITLE_BAR            1013
#define IDC_STATIC_ICON                 1014
#define IDC_STATIC_PALETTE_TITLE        1015
#define IDC_STATIC_HINT                 1016
#define IDC_STATIC_MESSAGE              1017
#define IDC_STATIC_MENU                 1018
#define IDC_STATIC_AUTHOR               1019
#define IDC_STATIC_NAME                 1020
#define IDC_STATIC_STYLE                1021
#define IDC_STATIC_SIZE                 1022
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_32774                        32774
#define IDM_EXIT                        32775
#define IDM_HELPTOPIC                   32776
#define IDM_ANOTHER                     32777
#define ID_32778                        32778
#define ID_32779                        32779
#define ID_Menu                         32780
#define IDM_OPEN                        32781
#define IDM_SAVE                        32782
#define ID_32783                        32783
#define IDM_SET_8                       32784
#define IDM_COMPAT7                     32786
#define ID_32787                        32787
#define IDM_SET_10                      32788
#define ID_Menu32789                    32789
#define ID_AAA_BBB                      32790
#define IDC_STATIC                      -1
#define IDC_STATIC_CHARSET              -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32791
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
